package gentreprise;


import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Departement {
    private final SimpleIntegerProperty id_departement;
    private final SimpleStringProperty nom_departement;
    private final SimpleIntegerProperty id_responsable;

    public Departement(int id, String nom, int responsable) {
        this.id_departement = new SimpleIntegerProperty(id);
        this.nom_departement = new SimpleStringProperty(nom);
        this.id_responsable = new SimpleIntegerProperty(responsable);
    }

    public int getId_departement() {
        return id_departement.get();
    }
    public void setId_departement(int id_departement) {
        this.id_departement.set(id_departement);
    }

    public String getNom_departement() {
        return nom_departement.get();
    }
public void setNom_departement(String nom_departement) {
        this.nom_departement.set(nom_departement);
}

    public int getId_responsable() {
        return id_responsable.get();
    }
    public void setId_responsable(int id_responsable) {
        this.id_responsable.set(id_responsable);
    }
}

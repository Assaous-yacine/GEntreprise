package gentreprise;

import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Requète{



        @FXML
        private ComboBox<String> requtecomobox;

        @FXML
        private TableView<ObservableList<String>> resultTable;

        private final String url = "jdbc:sqlite:GEntreprise.sqlite";

        @FXML
        public void initialize() {
            requtecomobox.setItems(FXCollections.observableArrayList(
                    "1 - Employés affectés à un projet",
                    "2 - Employés sans projet",
                    "3 - Projets sans employés",
                    "4 - Employés affectés uniquement à 'Application Mobile CNEP'",
                    "5 - Nombre de projets par employé"
            ));
        }

        @FXML
        private void handelExecute() {

                String selected = requtecomobox.getValue();
                String sql = "";

            switch (selected) {
                case "1 - Employés affectés à un projet":
                    sql = "SELECT e.nom, e.prenom, p.nom_projet " +
                            "FROM Employe e " +
                            "JOIN Travail t ON e.id_employe = t.id_employe " +
                            "JOIN Projet p ON t.id_projet = p.id_projet";
                    break;

                case "2 - Employés sans projet":
                    sql = "SELECT nom, prenom " +
                            "FROM Employe " +
                            "WHERE id_employe NOT IN (SELECT id_employe FROM Travail)";
                    break;

                case "3 - Projets sans employés":
                    sql = "SELECT nom_projet " +
                            "FROM Projet " +
                            "WHERE id_projet NOT IN (SELECT id_projet FROM Travail)";
                    break;

                case "4 - Employés affectés uniquement à 'Application Mobile CNEP'":
                    sql = "SELECT e.nom, e.prenom " +
                            "FROM Employe e " +
                            "WHERE e.id_employe IN ( " +
                            "    SELECT t.id_employe FROM Travail t " +
                            "    JOIN Projet p ON t.id_projet = p.id_projet " +
                            "    WHERE p.nom_projet = 'Application Mobile CNEP' " +
                            ") " +
                            "AND e.id_employe NOT IN ( " +
                            "    SELECT t.id_employe FROM Travail t " +
                            "    JOIN Projet p ON t.id_projet = p.id_projet " +
                            "    WHERE p.nom_projet != 'Application Mobile CNEP' " +
                            ")";
                    break;

                case "5 - Nombre de projets par employé":
                    sql = "SELECT e.nom, e.prenom, COUNT(t.id_projet) AS nombre_projets " +
                            "FROM Employe e " +
                            "LEFT JOIN Travail t ON e.id_employe = t.id_employe " +
                            "GROUP BY e.id_employe";
                    break;
            }


            loadQueryResults(sql);

        }
    private void loadQueryResults(String sql) {
        resultTable.getItems().clear();
        resultTable.getColumns().clear();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {


            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                final int j = i;
                TableColumn<ObservableList<String>, String> col = new TableColumn<>(rs.getMetaData().getColumnName(i + 1));
                col.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().get(j)));
                resultTable.getColumns().add(col);
            }
            while (rs.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    row.add(rs.getString(i));
                }
                resultTable.getItems().add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML private Button Principale;
    @FXML
    public void handleprincipale(ActionEvent event) {
        try{

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Bddadmin.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) Principale.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


}

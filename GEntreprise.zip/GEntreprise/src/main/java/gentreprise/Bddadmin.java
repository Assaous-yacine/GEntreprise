package gentreprise;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class Bddadmin {
    @FXML
    private TabPane tableG;

    @FXML
    private TableView<Departement> Departement;
    @FXML
    private TableColumn<Departement, Integer> id_departement;
    @FXML
    private TableColumn<Departement, String> nom_departement;
    @FXML
    private TableColumn<Departement, Integer> id_responsable;
    @FXML
    private ObservableList<Departement> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        id_departement.setCellValueFactory(new PropertyValueFactory<>("id_departement"));
        nom_departement.setCellValueFactory(new PropertyValueFactory<>("nom_departement"));
        id_responsable.setCellValueFactory(new PropertyValueFactory<>("id_responsable"));

        loadDepartementData();

        id_employe.setCellValueFactory(new PropertyValueFactory<>("id_employe"));
        nom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        prenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        poste.setCellValueFactory(new PropertyValueFactory<>("poste"));
        salaire.setCellValueFactory(new PropertyValueFactory<>("salaire"));
        id_departement1.setCellValueFactory(new PropertyValueFactory<>("id_departement"));

        loadEmployeData();

        id_projet.setCellValueFactory(new PropertyValueFactory<>("id_projet"));
        nom_projet.setCellValueFactory(new PropertyValueFactory<>("nom_projet"));
        budget.setCellValueFactory(new PropertyValueFactory<>("budget"));
        id_departement2.setCellValueFactory(new PropertyValueFactory<>("id_departement"));

        loadProjetData();

        id_employe1.setCellValueFactory(new PropertyValueFactory<>("id_employe"));
        id_projet1.setCellValueFactory(new PropertyValueFactory<>("id_projet"));
        date_affectation.setCellValueFactory(new PropertyValueFactory<>("date_affectation"));

        loadTravailData();


    }

    @FXML
    private void loadDepartementData() {
        String query = "SELECT * FROM Departement";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                data.add(new Departement(
                        rs.getInt("id_departement"),
                        rs.getString("nom_departement"),
                        rs.getInt("id_responsable")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Departement.setItems(data);
    }

    @FXML
    private TableView<Employe> Employe;

    @FXML
    private TableColumn<Employe, Integer> id_employe;

    @FXML
    private TableColumn<Employe, String> nom;

    @FXML
    private TableColumn<Employe, String> prenom;

    @FXML
    private TableColumn<Employe, String> poste;

    @FXML
    private TableColumn<Employe, Double> salaire;

    @FXML
    private TableColumn<Employe, Integer> id_departement1;

    ObservableList<Employe> employeData = FXCollections.observableArrayList();

    @FXML
    private void loadEmployeData() {

        String query = "SELECT * FROM Employe";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                employeData.add(new Employe(
                        rs.getInt("id_employe"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("poste"),
                        rs.getDouble("salaire"),
                        rs.getInt("id_departement")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Employe.setItems(employeData);
    }

    ObservableList<Projet> projetData = FXCollections.observableArrayList();

    @FXML
    private TableView<Projet> Projet;

    @FXML
    private TableColumn<Projet, Integer> id_projet;
    @FXML
    private TableColumn<Projet, String> nom_projet;
    @FXML
    private TableColumn<Projet, Double> budget;
    @FXML
    private TableColumn<Projet, Integer> id_departement2;

    private void loadProjetData() {
        String query = "SELECT * FROM Projet";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                projetData.add(new Projet(
                        rs.getInt("id_projet"),
                        rs.getString("nom_projet"),
                        rs.getDouble("budget"),
                        rs.getInt("id_departement")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Projet.setItems(projetData);
    }

    @FXML
    private TableView<Travail> Travail;

    @FXML
    private TableColumn<Travail, Integer> id_employe1;
    @FXML
    private TableColumn<Travail, Integer> id_projet1;
    @FXML
    private TableColumn<Travail, String> date_affectation;

    ObservableList<Travail> travailData = FXCollections.observableArrayList();

    private void loadTravailData() {
        String query = "SELECT * FROM Travail";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                travailData.add(new Travail(
                        rs.getInt("id_employe"),
                        rs.getInt("id_projet"),
                        rs.getString("date_affectation")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Travail.setItems(travailData);
    }

    @FXML
    void handleconsulter(ActionEvent event) {


        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        String details = "";

        switch (tabName) {
            case "Departement":
                Departement dept = Departement.getSelectionModel().getSelectedItem();
                if (dept != null) {
                    details = "ID Département : " + dept.getId_departement() + "\n"
                            + "Nom : " + dept.getNom_departement();
                }
                break;

            case "Employe":
                Employe emp = Employe.getSelectionModel().getSelectedItem();
                if (emp != null) {
                    details = "ID Employé : " + emp.getId_employe() + "\n"
                            + "Nom : " + emp.getNom() + "\n"
                            + "Prénom : " + emp.getPrenom() + "\n"
                            + "ID Département : " + emp.getId_departement();
                }
                break;

            case "Projet":
                Projet proj = Projet.getSelectionModel().getSelectedItem();
                if (proj != null) {
                    details = "ID Projet : " + proj.getId_projet() + "\n"
                            + "Nom : " + proj.getNom_projet() + "\n"
                            + "Budget : " + proj.getBudget();
                }
                break;

            case "Travail":
                Travail travail = Travail.getSelectionModel().getSelectedItem();
                if (travail != null) {
                    details = "ID Employé : " + travail.getId_employe() + "\n"
                            + "ID Projet : " + travail.getId_projet() + "\n"
                            + "la Date affectation  : " + travail.getDate_affectation();
                }
                break;
        }

        if (!details.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Détails");
            alert.setHeaderText("Informations de l'enregistrement sélectionné");
            alert.setContentText(details);
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucune sélection");
            alert.setHeaderText("Aucun enregistrement sélectionné");
            alert.setContentText("Veuillez sélectionner une ligne dans le tableau.");
            alert.showAndWait();
        }
    }


    @FXML
    void handlesupprimer(ActionEvent event) {
        String selectedTab = tableG.getSelectionModel().getSelectedItem().getText();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            switch (selectedTab) {
                case "Departement":
                    Departement d = Departement.getSelectionModel().getSelectedItem();
                    if (d != null) {
                        String sql = "DELETE FROM Departement WHERE id_departement = ?";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, d.getId_departement());
                            ps.executeUpdate();
                            data.remove(d);
                        }
                    }
                    break;
                case "Employe":
                    Employe e = Employe.getSelectionModel().getSelectedItem();
                    if (e != null) {
                        String sql = "DELETE FROM Employe WHERE id_employe = ?";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, e.getId_employe());
                            ps.executeUpdate();
                            employeData.remove(e);
                        }
                    }
                    break;
                case "Projet":
                    Projet p = Projet.getSelectionModel().getSelectedItem();
                    if (p != null) {
                        String sql = "DELETE FROM Projet WHERE id_projet = ?";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, p.getId_projet());
                            ps.executeUpdate();
                            projetData.remove(p);
                        }
                    }
                    break;
                case "Travail":
                    Travail t = Travail.getSelectionModel().getSelectedItem();
                    if (t != null) {
                        String sql = "DELETE FROM Travail WHERE id_employe = ? AND id_projet = ?";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, t.getId_employe());
                            ps.setInt(2, t.getId_projet());
                            ps.executeUpdate();
                            travailData.remove(t);
                        }
                    }
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handleinsere(ActionEvent event) {
        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            PreparedStatement stmt;

            switch (tabName) {
                case "Departement":
                    TextInputDialog d1 = new TextInputDialog();
                    d1.setHeaderText("ID Département");
                    int id_dept = Integer.parseInt(d1.showAndWait().orElse("0"));

                    TextInputDialog d2 = new TextInputDialog();
                    d2.setHeaderText("Nom Département");
                    String nom_dept = d2.showAndWait().orElse("");

                    TextInputDialog d3 = new TextInputDialog();
                    d3.setHeaderText("ID Responsable");
                    int id_resp = Integer.parseInt(d3.showAndWait().orElse("0"));

                    stmt = conn.prepareStatement("INSERT INTO Departement VALUES (?, ?, ?)");
                    stmt.setInt(1, id_dept);
                    stmt.setString(2, nom_dept);
                    stmt.setInt(3, id_resp);
                    stmt.executeUpdate();
                    data.clear();
                    loadDepartementData();
                    break;

                case "Employe":
                    TextInputDialog e1 = new TextInputDialog();
                    e1.setHeaderText("ID Employé");
                    int id_emp = Integer.parseInt(e1.showAndWait().orElse("0"));

                    TextInputDialog e2 = new TextInputDialog();
                    e2.setHeaderText("Nom");
                    String nom = e2.showAndWait().orElse("");

                    TextInputDialog e3 = new TextInputDialog();
                    e3.setHeaderText("Prénom");
                    String prenom = e3.showAndWait().orElse("");

                    TextInputDialog e4 = new TextInputDialog();
                    e4.setHeaderText("Poste");
                    String poste = e4.showAndWait().orElse("");

                    TextInputDialog e5 = new TextInputDialog();
                    e5.setHeaderText("Salaire");
                    double salaire = Double.parseDouble(e5.showAndWait().orElse("0"));

                    TextInputDialog e6 = new TextInputDialog();
                    e6.setHeaderText("ID Département");
                    int id_dep = Integer.parseInt(e6.showAndWait().orElse("0"));

                    stmt = conn.prepareStatement("INSERT INTO Employe VALUES (?, ?, ?, ?, ?, ?)");
                    stmt.setInt(1, id_emp);
                    stmt.setString(2, nom);
                    stmt.setString(3, prenom);
                    stmt.setString(4, poste);
                    stmt.setDouble(5, salaire);
                    stmt.setInt(6, id_dep);
                    stmt.executeUpdate();
                    employeData.clear();
                    loadEmployeData();
                    break;

                case "Projet":
                    TextInputDialog p1 = new TextInputDialog();
                    p1.setHeaderText("ID Projet");
                    int id_proj = Integer.parseInt(p1.showAndWait().orElse("0"));

                    TextInputDialog p2 = new TextInputDialog();
                    p2.setHeaderText("Nom Projet");
                    String nom_proj = p2.showAndWait().orElse("");

                    TextInputDialog p3 = new TextInputDialog();
                    p3.setHeaderText("Budget");
                    double budget = Double.parseDouble(p3.showAndWait().orElse("0"));

                    TextInputDialog p4 = new TextInputDialog();
                    p4.setHeaderText("ID Département");
                    int id_dep_proj = Integer.parseInt(p4.showAndWait().orElse("0"));

                    stmt = conn.prepareStatement("INSERT INTO Projet VALUES (?, ?, ?, ?)");
                    stmt.setInt(1, id_proj);
                    stmt.setString(2, nom_proj);
                    stmt.setDouble(3, budget);
                    stmt.setInt(4, id_dep_proj);
                    stmt.executeUpdate();
                    projetData.clear();
                    loadProjetData();
                    break;

                case "Travail":
                    TextInputDialog t1 = new TextInputDialog();
                    t1.setHeaderText("ID Employé");
                    int id_emp_trav = Integer.parseInt(t1.showAndWait().orElse("0"));

                    TextInputDialog t2 = new TextInputDialog();
                    t2.setHeaderText("ID Projet");
                    int id_proj_trav = Integer.parseInt(t2.showAndWait().orElse("0"));

                    TextInputDialog t3 = new TextInputDialog();
                    t3.setHeaderText("Date Affectation (YYYY-MM-DD)");
                    String date = t3.showAndWait().orElse("");

                    stmt = conn.prepareStatement("INSERT INTO Travail VALUES (?, ?, ?)");
                    stmt.setInt(1, id_emp_trav);
                    stmt.setInt(2, id_proj_trav);
                    stmt.setString(3, date);
                    stmt.executeUpdate();
                    travailData.clear();
                    loadTravailData();
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handlemodifier(ActionEvent event) {
        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            PreparedStatement stmt;

            switch (tabName) {
                case "Departement":
                    Departement selectedDept = Departement.getSelectionModel().getSelectedItem();
                    if (selectedDept == null) return;

                    TextInputDialog d1 = new TextInputDialog(selectedDept.getNom_departement());
                    d1.setHeaderText("Nouveau nom de département");
                    String nom_dept = d1.showAndWait().orElse(selectedDept.getNom_departement());

                    TextInputDialog d2 = new TextInputDialog(String.valueOf(selectedDept.getId_responsable()));
                    d2.setHeaderText("Nouveau ID Responsable");
                    int id_resp = Integer.parseInt(d2.showAndWait().orElse(String.valueOf(selectedDept.getId_responsable())));

                    stmt = conn.prepareStatement("UPDATE Departement SET nom_departement = ?, id_responsable = ? WHERE Id_departement = ?");
                    stmt.setString(1, nom_dept);
                    stmt.setInt(2, id_resp);
                    stmt.setInt(3, selectedDept.getId_departement());
                    stmt.executeUpdate();
                    data.clear();
                    loadDepartementData();
                    break;

                case "Employe":
                    Employe selectedEmp = Employe.getSelectionModel().getSelectedItem();
                    if (selectedEmp == null) return;

                    TextInputDialog e1 = new TextInputDialog(selectedEmp.getNom());
                    e1.setHeaderText("Nom");
                    String nom = e1.showAndWait().orElse(selectedEmp.getNom());

                    TextInputDialog e2 = new TextInputDialog(selectedEmp.getPrenom());
                    e2.setHeaderText("Prénom");
                    String prenom = e2.showAndWait().orElse(selectedEmp.getPrenom());

                    TextInputDialog e3 = new TextInputDialog(selectedEmp.getPoste());
                    e3.setHeaderText("Poste");
                    String poste = e3.showAndWait().orElse(selectedEmp.getPoste());

                    TextInputDialog e4 = new TextInputDialog(String.valueOf(selectedEmp.getSalaire()));
                    e4.setHeaderText("Salaire");
                    double salaire = Double.parseDouble(e4.showAndWait().orElse(String.valueOf(selectedEmp.getSalaire())));

                    TextInputDialog e5 = new TextInputDialog(String.valueOf(selectedEmp.getId_departement()));
                    e5.setHeaderText("ID Département");
                    int id_dep = Integer.parseInt(e5.showAndWait().orElse(String.valueOf(selectedEmp.getId_departement())));

                    stmt = conn.prepareStatement("UPDATE Employe SET nom = ?, prenom = ?, poste = ?, salaire = ?, id_departement = ? WHERE id_employe = ?");
                    stmt.setString(1, nom);
                    stmt.setString(2, prenom);
                    stmt.setString(3, poste);
                    stmt.setDouble(4, salaire);
                    stmt.setInt(5, id_dep);
                    stmt.setInt(6, selectedEmp.getId_employe());
                    stmt.executeUpdate();
                    employeData.clear();
                    loadEmployeData();
                    break;

                case "Projet":
                    Projet selectedProj = Projet.getSelectionModel().getSelectedItem();
                    if (selectedProj == null) return;

                    TextInputDialog p1 = new TextInputDialog(selectedProj.getNom_projet());
                    p1.setHeaderText("Nom Projet");
                    String nom_proj = p1.showAndWait().orElse(selectedProj.getNom_projet());

                    TextInputDialog p2 = new TextInputDialog(String.valueOf(selectedProj.getBudget()));
                    p2.setHeaderText("Budget");
                    double budget = Double.parseDouble(p2.showAndWait().orElse(String.valueOf(selectedProj.getBudget())));

                    TextInputDialog p3 = new TextInputDialog(String.valueOf(selectedProj.getId_departement()));
                    p3.setHeaderText("ID Département");
                    int id_dep_proj = Integer.parseInt(p3.showAndWait().orElse(String.valueOf(selectedProj.getId_departement())));

                    stmt = conn.prepareStatement("UPDATE Projet SET nom_projet = ?, budget = ?, id_departement = ? WHERE id_projet = ?");
                    stmt.setString(1, nom_proj);
                    stmt.setDouble(2, budget);
                    stmt.setInt(3, id_dep_proj);
                    stmt.setInt(4, selectedProj.getId_projet());
                    stmt.executeUpdate();
                    projetData.clear();
                    loadProjetData();
                    break;

                case "Travail":
                    Travail selectedTravail = Travail.getSelectionModel().getSelectedItem();
                    if (selectedTravail == null) return;

                    TextInputDialog t1 = new TextInputDialog(selectedTravail.getDate_affectation());
                    t1.setHeaderText("Nouvelle date (YYYY-MM-DD)");
                    String date = t1.showAndWait().orElse(selectedTravail.getDate_affectation());

                    stmt = conn.prepareStatement("UPDATE Travail SET date_affectation = ? WHERE id_employe = ? AND id_projet = ?");
                    stmt.setString(1, date);
                    stmt.setInt(2, selectedTravail.getId_employe());
                    stmt.setInt(3, selectedTravail.getId_projet());
                    stmt.executeUpdate();
                    travailData.clear();
                    loadTravailData();
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handlerecherche(ActionEvent event) {

        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Recherche");
        dialog.setHeaderText("Rechercher par ID");
        dialog.setContentText("Entrez l'ID :");
        Optional<String> result = dialog.showAndWait();

        if (result.isEmpty()) return;

        String inputId = result.get().trim();
        if (inputId.isEmpty()) return;

        try {
            int id = Integer.parseInt(inputId);

            switch (tabName) {
                case "Departement":
                    for (Departement dept : Departement.getItems()) {
                        if (dept.getId_departement() == id) {
                            Departement.getSelectionModel().select(dept);
                            Departement.scrollTo(dept);
                            return;
                        }
                    }
                    break;

                case "Employe":
                    for (Employe emp : Employe.getItems()) {
                        if (emp.getId_employe() == id) {
                            Employe.getSelectionModel().select(emp);
                            Employe.scrollTo(emp);
                            return;
                        }
                    }
                    break;

                case "Projet":
                    for (Projet proj : Projet.getItems()) {
                        if (proj.getId_projet() == id) {
                            Projet.getSelectionModel().select(proj);
                            Projet.scrollTo(proj);
                            return;
                        }
                    }
                    break;

                case "Travail":

                    TextInputDialog secondDialog = new TextInputDialog();
                    secondDialog.setTitle("Recherche Travail");
                    secondDialog.setHeaderText("Entrez l'ID Projet correspondant");
                    secondDialog.setContentText("ID Projet :");
                    Optional<String> res = secondDialog.showAndWait();
                    if (res.isEmpty()) return;
                    int id_proj = Integer.parseInt(res.get());

                    for (Travail travail : Travail.getItems()) {
                        if (travail.getId_employe() == id && travail.getId_projet() == id_proj) {
                            Travail.getSelectionModel().select(travail);
                            Travail.scrollTo(travail);
                            return;
                        }
                    }
                    break;
            }


            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Résultat");
            alert.setHeaderText("Aucun enregistrement trouvé");
            alert.setContentText("Aucun résultat pour l'ID fourni.");
            alert.showAndWait();

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Entrée invalide");
            alert.setContentText("Veuillez entrer un nombre entier.");
            alert.showAndWait();
        }
    }
    @FXML
    private Button Requete;

    @FXML
    public void handlerequete(ActionEvent event) {
        try{

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Requète.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) Requete.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    @FXML
    private Button Logout;
    @FXML
    public void handlelogout(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) Logout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}













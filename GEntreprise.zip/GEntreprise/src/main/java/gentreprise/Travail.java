package gentreprise;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Travail {
    private final SimpleIntegerProperty id_employe;
    private final SimpleIntegerProperty id_projet;
    private final SimpleStringProperty date_affectation;

    public Travail(int idEmploye, int idProjet, String dateAffectation) {
        this.id_employe = new SimpleIntegerProperty(idEmploye);
        this.id_projet = new SimpleIntegerProperty(idProjet);
        this.date_affectation = new SimpleStringProperty(dateAffectation);
    }

    public int getId_employe() {
        return id_employe.get();
    }

    public int getId_projet() {
        return id_projet.get();
    }

    public String getDate_affectation() {
        return date_affectation.get();
    }
}

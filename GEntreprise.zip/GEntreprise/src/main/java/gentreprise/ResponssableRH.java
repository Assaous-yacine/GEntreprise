package gentreprise;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class ResponssableRH {
    @FXML
    private TableView<Employe> Employe;

    @FXML
    private TableColumn<Employe, Integer> id_employe;

    @FXML
    private TableColumn<Employe, String> nom;

    @FXML
    private TableColumn<Employe, String> prenom;

    @FXML
    private TableColumn<Employe, String> poste;

    @FXML
    private TableColumn<Employe, Double> salaire;

    @FXML
    private TableColumn<Employe, Integer> id_departement;

    public void initialize() {
        id_employe.setCellValueFactory(new PropertyValueFactory<>("id_employe"));
        nom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        prenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        poste.setCellValueFactory(new PropertyValueFactory<>("poste"));
        salaire.setCellValueFactory(new PropertyValueFactory<>("salaire"));
        id_departement.setCellValueFactory(new PropertyValueFactory<>("id_departement"));

        loadEmployeData();
    }

    ObservableList<Employe> employeData = FXCollections.observableArrayList();

    @FXML
    private void loadEmployeData() {

        String query = "SELECT * FROM Employe";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                employeData.add(new Employe(
                        rs.getInt("id_employe"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("poste"),
                        rs.getDouble("salaire"),
                        rs.getInt("id_departement")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Employe.setItems(employeData);
    }

    @FXML
    private void handleconsulter(ActionEvent event) {
        Employe emp = Employe.getSelectionModel().getSelectedItem();

        if (emp != null) {
            String details = "ID Employé : " + emp.getId_employe() + "\n"
                    + "Nom : " + emp.getNom() + "\n"
                    + "Prénom : " + emp.getPrenom() + "\n"
                    + "ID Département : " + emp.getId_departement();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Détails Employé");
            alert.setHeaderText("Informations de l'employé sélectionné");
            alert.setContentText(details);
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucune sélection");
            alert.setHeaderText("Aucun employé sélectionné");
            alert.setContentText("Veuillez sélectionner un employé dans le tableau.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleinsere(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Insertion Employé");
        dialog.setHeaderText("Ajout d'un nouvel employé");
        dialog.setContentText("Format : nom,prenom,poste,salaire,id_departement");


        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            PreparedStatement stmt;

        TextInputDialog e1 = new TextInputDialog();
        e1.setHeaderText("ID Employé");
        int id_emp = Integer.parseInt(e1.showAndWait().orElse("0"));

        TextInputDialog e2 = new TextInputDialog();
        e2.setHeaderText("Nom");
        String nom = e2.showAndWait().orElse("");

        TextInputDialog e3 = new TextInputDialog();
        e3.setHeaderText("Prénom");
        String prenom = e3.showAndWait().orElse("");

        TextInputDialog e4 = new TextInputDialog();
        e4.setHeaderText("Poste");
        String poste = e4.showAndWait().orElse("");

        TextInputDialog e5 = new TextInputDialog();
        e5.setHeaderText("Salaire");
        double salaire = Double.parseDouble(e5.showAndWait().orElse("0"));

        TextInputDialog e6 = new TextInputDialog();
        e6.setHeaderText("ID Département");
        int id_dep = Integer.parseInt(e6.showAndWait().orElse("0"));

        stmt = conn.prepareStatement("INSERT INTO Employe VALUES (?, ?, ?, ?, ?, ?)");
        stmt.setInt(1, id_emp);
        stmt.setString(2, nom);
        stmt.setString(3, prenom);
        stmt.setString(4, poste);
        stmt.setDouble(5, salaire);
        stmt.setInt(6, id_dep);
        stmt.executeUpdate();
        employeData.clear();
        loadEmployeData();
            } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    private void handlesupprimer(ActionEvent event) {
        Employe emp = Employe.getSelectionModel().getSelectedItem();
        if (emp == null) {
            showAlert("Avertissement", "Veuillez sélectionner un employé à supprimer.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            String sql = "DELETE FROM Employe WHERE id_employe = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, emp.getId_employe());
            pstmt.executeUpdate();

            employeData.clear();
            loadEmployeData();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Suppression échouée : " + e.getMessage());
        }
    }
    @FXML
    private void handlemodifier(ActionEvent event) {
        Employe emp = Employe.getSelectionModel().getSelectedItem();
        if (emp == null) {
            showAlert("Avertissement", "Veuillez sélectionner un employé à modifier.");
            return;
        }
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            PreparedStatement stmt;

            Employe selectedEmp = Employe.getSelectionModel().getSelectedItem();
            if (selectedEmp == null) return;

            TextInputDialog e1 = new TextInputDialog(selectedEmp.getNom());
            e1.setHeaderText("Nom");
            String nom = e1.showAndWait().orElse(selectedEmp.getNom());

            TextInputDialog e2 = new TextInputDialog(selectedEmp.getPrenom());
            e2.setHeaderText("Prénom");
            String prenom = e2.showAndWait().orElse(selectedEmp.getPrenom());

            TextInputDialog e3 = new TextInputDialog(selectedEmp.getPoste());
            e3.setHeaderText("Poste");
            String poste = e3.showAndWait().orElse(selectedEmp.getPoste());

            TextInputDialog e4 = new TextInputDialog(String.valueOf(selectedEmp.getSalaire()));
            e4.setHeaderText("Salaire");
            double salaire = Double.parseDouble(e4.showAndWait().orElse(String.valueOf(selectedEmp.getSalaire())));

            TextInputDialog e5 = new TextInputDialog(String.valueOf(selectedEmp.getId_departement()));
            e5.setHeaderText("ID Département");
            int id_dep = Integer.parseInt(e5.showAndWait().orElse(String.valueOf(selectedEmp.getId_departement())));

            stmt = conn.prepareStatement("UPDATE Employe SET nom = ?, prenom = ?, poste = ?, salaire = ?, id_departement = ? WHERE id_employe = ?");
            stmt.setString(1, nom);
            stmt.setString(2, prenom);
            stmt.setString(3, poste);
            stmt.setDouble(4, salaire);
            stmt.setInt(5, id_dep);
            stmt.setInt(6, selectedEmp.getId_employe());
            stmt.executeUpdate();
            employeData.clear();
            loadEmployeData();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    private void handlerecherche(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Recherche Employé");
        dialog.setHeaderText("Recherche par nom");
        dialog.setContentText("Nom à rechercher :");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(name -> {
            ObservableList<Employe> searchResults = FXCollections.observableArrayList();

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
                String sql = "SELECT * FROM Employe WHERE nom LIKE ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + name + "%");
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    searchResults.add(new Employe(
                            rs.getInt("id_employe"),
                            rs.getString("nom"),
                            rs.getString("prenom"),
                            rs.getString("poste"),
                            rs.getDouble("salaire"),
                            rs.getInt("id_departement")
                    ));
                }

                Employe.setItems(searchResults);

            } catch (Exception e) {
                e.printStackTrace();
                showAlert("Erreur", "Recherche échouée : " + e.getMessage());
            }
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private Button Logout;
    @FXML
    public void handlelogout(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) Logout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}


package gentreprise;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Employe {
    private final SimpleIntegerProperty id_employe;
    private final SimpleStringProperty nom;
    private final SimpleStringProperty prenom;
    private final SimpleStringProperty poste;
    private final SimpleDoubleProperty salaire;
    private final SimpleIntegerProperty id_departement;

    public Employe(int id, String nom, String prenom, String poste, double salaire, int id_departement) {
        this.id_employe = new SimpleIntegerProperty(id);
        this.nom = new SimpleStringProperty(nom);
        this.prenom = new SimpleStringProperty(prenom);
        this.poste = new SimpleStringProperty(poste);
        this.salaire = new SimpleDoubleProperty(salaire);
        this.id_departement = new SimpleIntegerProperty(id_departement);
    }

    public int getId_employe() { return id_employe.get(); }
    public String getNom() { return nom.get(); }
    public String getPrenom() { return prenom.get(); }
    public String getPoste() { return poste.get(); }
    public double getSalaire() { return salaire.get(); }
    public int getId_departement() { return id_departement.get(); }
}



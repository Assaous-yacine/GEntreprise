package gentreprise;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class Login {

    @FXML
    private TextField username;

    @FXML
    private PasswordField passwordfield;

    @FXML
    private Label errorLabel;

    @FXML
    public void handleLogin(ActionEvent event) {
        String user = username.getText();
        String pass = passwordfield.getText();

        try {
            if (user.equals("Bddadmin") && pass.equals("tpadmin")) {
                loadScene(event, "Bddadmin.fxml");
            } else if (user.equals("ResponssableRh") && pass.equals("tpRh")) {
                loadScene(event, "Responssablerh.fxml");
            } else if (user.equals("Responssableprojet") && pass.equals("tpProjet")) {
                loadScene(event, "Responssablep.fxml");}
             else  {
                showError("Nom d'utilisateur ou mot de passe incorrect.");
            }
        } catch (IOException e) {
            showError("Erreur lors du chargement de l'interface.");
            e.printStackTrace();
        }
    }

    private void loadScene(ActionEvent event, String fxmlFile) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    private void showError(String message) {
        if (errorLabel != null) {
            errorLabel.setText(message);
            errorLabel.setVisible(true);
        } else {
            System.err.println("Erreur : " + message);
        }
    }
}

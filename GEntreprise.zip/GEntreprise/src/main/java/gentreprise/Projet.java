package gentreprise;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Projet {
    private final SimpleIntegerProperty id_projet;
    private final SimpleStringProperty nom_projet;
    private final SimpleDoubleProperty budget;
    private final SimpleIntegerProperty id_departement;

    public Projet(int id, String nom, double budget, int id_departement) {
        this.id_projet = new SimpleIntegerProperty(id);
        this.nom_projet = new SimpleStringProperty(nom);
        this.budget = new SimpleDoubleProperty(budget);
        this.id_departement = new SimpleIntegerProperty(id_departement);
    }

    public int getId_projet() { return id_projet.get(); }
    public String getNom_projet() { return nom_projet.get(); }
    public double getBudget() { return budget.get(); }
    public int getId_departement() { return id_departement.get(); }
}

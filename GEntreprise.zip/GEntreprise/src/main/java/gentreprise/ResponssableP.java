package gentreprise;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class ResponssableP {
    @FXML
    private TabPane tableG;
    @FXML
    private TableView<Projet> Projet;
    @FXML
    private TableColumn<Projet, Integer> id_projet;
    @FXML
    private TableColumn<Projet, String> nom_projet;
    @FXML
    private TableColumn<Projet, Double> budget;
    @FXML
    private TableColumn<Projet, Integer> id_departement;


    @FXML
    public void initialize() {
        // Projet
        id_projet.setCellValueFactory(new PropertyValueFactory<>("id_projet"));
        nom_projet.setCellValueFactory(new PropertyValueFactory<>("nom_projet"));
        budget.setCellValueFactory(new PropertyValueFactory<>("budget"));
        id_departement.setCellValueFactory(new PropertyValueFactory<>("id_departement"));
        loadProjetData();

        // Travail
        id_employe.setCellValueFactory(new PropertyValueFactory<>("id_employe"));
        id_projet1.setCellValueFactory(new PropertyValueFactory<>("id_projet"));
        date_affectation.setCellValueFactory(new PropertyValueFactory<>("date_affectation"));
        loadTravailData();
    }

    ObservableList<Projet> projetData = FXCollections.observableArrayList();

    private void loadProjetData() {
        String query = "SELECT * FROM Projet";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                projetData.add(new Projet(
                        rs.getInt("id_projet"),
                        rs.getString("nom_projet"),
                        rs.getDouble("budget"),
                        rs.getInt("id_departement")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Projet.setItems(projetData);
    }


    @FXML
    private TableView<Travail> Travail;
    @FXML
    private TableColumn<Travail, Integer> id_employe;
    @FXML
    private TableColumn<Travail, Integer> id_projet1;
    @FXML
    private TableColumn<Travail, String> date_affectation;

    ObservableList<Travail> travailData = FXCollections.observableArrayList();

    private void loadTravailData() {
        String query = "SELECT * FROM Travail";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                travailData.add(new Travail(
                        rs.getInt("id_employe"),
                        rs.getInt("id_projet"),
                        rs.getString("date_affectation")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Travail.setItems(travailData);
    }
    @FXML
    void handleconsulter(ActionEvent event) {


        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        String details = "";

        switch (tabName) {

            case "Projet":
                Projet proj = Projet.getSelectionModel().getSelectedItem();
                if (proj != null) {
                    details = "ID Projet : " + proj.getId_projet() + "\n"
                            + "Nom : " + proj.getNom_projet() + "\n"
                            + "Budget : " + proj.getBudget();
                }
                break;

            case "Travail":
                Travail travail = Travail.getSelectionModel().getSelectedItem();
                if (travail != null) {
                    details = "ID Employé : " + travail.getId_employe() + "\n"
                            + "ID Projet : " + travail.getId_projet() + "\n"
                            + "la Date affectation  : " + travail.getDate_affectation();
                }
                break;
        }

        if (!details.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Détails");
            alert.setHeaderText("Informations de l'enregistrement sélectionné");
            alert.setContentText(details);
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucune sélection");
            alert.setHeaderText("Aucun enregistrement sélectionné");
            alert.setContentText("Veuillez sélectionner une ligne dans le tableau.");
            alert.showAndWait();
        }
    }

    @FXML
    void handlesupprimer (ActionEvent event) {
        String selectedTab = tableG.getSelectionModel().getSelectedItem().getText();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            switch (selectedTab) {

                case "Projet":
                    Projet p = Projet.getSelectionModel().getSelectedItem();
                    if (p != null) {
                        String sql = "DELETE FROM Projet WHERE id_projet = ?";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, p.getId_projet());
                            ps.executeUpdate();
                            projetData.remove(p);
                        }
                    }
                    break;
                case "Travail":
                    Travail t = Travail.getSelectionModel().getSelectedItem();
                    if (t != null) {
                        String sql = "DELETE FROM Travail WHERE id_employe = ? AND id_projet = ?";
                        try (PreparedStatement ps = conn.prepareStatement(sql)) {
                            ps.setInt(1, t.getId_employe());
                            ps.setInt(2, t.getId_projet());
                            ps.executeUpdate();
                            travailData.remove(t);
                        }
                    }
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handleinsere(ActionEvent event) {
        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            PreparedStatement stmt;

            switch (tabName) {

                case "Projet":
                    TextInputDialog p1 = new TextInputDialog();
                    p1.setHeaderText("ID Projet");
                    int id_proj = Integer.parseInt(p1.showAndWait().orElse("0"));

                    TextInputDialog p2 = new TextInputDialog();
                    p2.setHeaderText("Nom Projet");
                    String nom_proj = p2.showAndWait().orElse("");

                    TextInputDialog p3 = new TextInputDialog();
                    p3.setHeaderText("Budget");
                    double budget = Double.parseDouble(p3.showAndWait().orElse("0"));

                    TextInputDialog p4 = new TextInputDialog();
                    p4.setHeaderText("ID Département");
                    int id_dep_proj = Integer.parseInt(p4.showAndWait().orElse("0"));

                    stmt = conn.prepareStatement("INSERT INTO Projet VALUES (?, ?, ?, ?)");
                    stmt.setInt(1, id_proj);
                    stmt.setString(2, nom_proj);
                    stmt.setDouble(3, budget);
                    stmt.setInt(4, id_dep_proj);
                    stmt.executeUpdate();
                    projetData.clear();
                    loadProjetData();
                    break;

                case "Travail":
                    TextInputDialog t1 = new TextInputDialog();
                    t1.setHeaderText("ID Employé");
                    int id_emp_trav = Integer.parseInt(t1.showAndWait().orElse("0"));

                    TextInputDialog t2 = new TextInputDialog();
                    t2.setHeaderText("ID Projet");
                    int id_proj_trav = Integer.parseInt(t2.showAndWait().orElse("0"));

                    TextInputDialog t3 = new TextInputDialog();
                    t3.setHeaderText("Date Affectation (YYYY-MM-DD)");
                    String date = t3.showAndWait().orElse("");

                    stmt = conn.prepareStatement("INSERT INTO Travail VALUES (?, ?, ?)");
                    stmt.setInt(1, id_emp_trav);
                    stmt.setInt(2, id_proj_trav);
                    stmt.setString(3, date);
                    stmt.executeUpdate();
                    travailData.clear();
                    loadTravailData();
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    void handlemodifier(ActionEvent event) {
        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:GEntreprise.sqlite")) {
            PreparedStatement stmt;

            switch (tabName) {


                case "Projet":
                    Projet selectedProj = Projet.getSelectionModel().getSelectedItem();
                    if (selectedProj == null) return;

                    TextInputDialog p1 = new TextInputDialog(selectedProj.getNom_projet());
                    p1.setHeaderText("Nom Projet");
                    String nom_proj = p1.showAndWait().orElse(selectedProj.getNom_projet());

                    TextInputDialog p2 = new TextInputDialog(String.valueOf(selectedProj.getBudget()));
                    p2.setHeaderText("Budget");
                    double budget = Double.parseDouble(p2.showAndWait().orElse(String.valueOf(selectedProj.getBudget())));

                    TextInputDialog p3 = new TextInputDialog(String.valueOf(selectedProj.getId_departement()));
                    p3.setHeaderText("ID Département");
                    int id_dep_proj = Integer.parseInt(p3.showAndWait().orElse(String.valueOf(selectedProj.getId_departement())));

                    stmt = conn.prepareStatement("UPDATE Projet SET nom_projet = ?, budget = ?, id_departement = ? WHERE id_projet = ?");
                    stmt.setString(1, nom_proj);
                    stmt.setDouble(2, budget);
                    stmt.setInt(3, id_dep_proj);
                    stmt.setInt(4, selectedProj.getId_projet());
                    stmt.executeUpdate();
                    projetData.clear();
                    loadProjetData();
                    break;

                case "Travail":
                    Travail selectedTravail = Travail.getSelectionModel().getSelectedItem();
                    if (selectedTravail == null) return;

                    TextInputDialog t1 = new TextInputDialog(selectedTravail.getDate_affectation());
                    t1.setHeaderText("Nouvelle date (YYYY-MM-DD)");
                    String date = t1.showAndWait().orElse(selectedTravail.getDate_affectation());

                    stmt = conn.prepareStatement("UPDATE Travail SET date_affectation = ? WHERE id_employe = ? AND id_projet = ?");
                    stmt.setString(1, date);
                    stmt.setInt(2, selectedTravail.getId_employe());
                    stmt.setInt(3, selectedTravail.getId_projet());
                    stmt.executeUpdate();
                    travailData.clear();
                    loadTravailData();
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handlerecherche(ActionEvent event) {

        TabPane tabPane = (TabPane) tableG.getScene().lookup(".tab-pane");
        Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
        String tabName = selectedTab.getText();

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Recherche");
        dialog.setHeaderText("Rechercher par ID");
        dialog.setContentText("Entrez l'ID :");
        Optional<String> result = dialog.showAndWait();

        if (result.isEmpty()) return;

        String inputId = result.get().trim();
        if (inputId.isEmpty()) return;

        try {
            int id = Integer.parseInt(inputId);

            switch (tabName) {


                case "Projet":
                    for (Projet proj : Projet.getItems()) {
                        if (proj.getId_projet() == id) {
                            Projet.getSelectionModel().select(proj);
                            Projet.scrollTo(proj);
                            return;
                        }
                    }
                    break;

                case "Travail":

                    TextInputDialog secondDialog = new TextInputDialog();
                    secondDialog.setTitle("Recherche Travail");
                    secondDialog.setHeaderText("Entrez l'ID Projet correspondant");
                    secondDialog.setContentText("ID Projet :");
                    Optional<String> res = secondDialog.showAndWait();
                    if (res.isEmpty()) return;
                    int id_proj = Integer.parseInt(res.get());

                    for (Travail travail : Travail.getItems()) {
                        if (travail.getId_employe() == id && travail.getId_projet() == id_proj) {
                            Travail.getSelectionModel().select(travail);
                            Travail.scrollTo(travail);
                            return;
                        }
                    }
                    break;
            }


            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Résultat");
            alert.setHeaderText("Aucun enregistrement trouvé");
            alert.setContentText("Aucun résultat pour l'ID fourni.");
            alert.showAndWait();

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Entrée invalide");
            alert.setContentText("Veuillez entrer un nombre entier.");
            alert.showAndWait();
        }
    }
    @FXML
    private Button Logout;
    @FXML
    public void handlelogout(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) Logout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

}
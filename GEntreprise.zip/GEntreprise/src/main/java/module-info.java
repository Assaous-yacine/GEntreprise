module gentreprise.gentreprise {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jdk.jdi;


    opens gentreprise to javafx.fxml;
    exports gentreprise;
}